/*
 * Xlib compatibility
 */

/* Nothing yet */
